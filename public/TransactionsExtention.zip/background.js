chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(message.action);
  if (message.action === "sendTransactionData") {
    console.log("Nhận được dữ liệu giao dịch từ content script:", message.data);

    // Gửi dữ liệu đến API backend
    fetch("http://localhost:2000/data/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transactions: message.data })
    })
    .then(response => response.json())
    .then(data => {
      console.log("Phản hồi từ server:", data);
      sendResponse({ success: true, serverResponse: data });
    })
    .catch(error => {
      console.error("Lỗi khi gửi dữ liệu lên server:", error);
      sendResponse({ success: false, error });
    });

    return true; // Giữ kết nối mở cho sendResponse
  }
});
