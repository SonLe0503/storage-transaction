
const targetSelector = ".block-result.ng-star-inserted"; // Thay bằng ID/selector của lịch sử giao dịch

const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    console.log("DOM thay đổi, kiểm tra dữ liệu mới...");
    const transactionData = document.querySelector(targetSelector);
    if (transactionData) {
      console.log("Dữ liệu mới:", transactionData.innerText);
    }
  });
});

// Chờ phần tử xuất hiện rồi mới theo dõi
function waitForElement(selector, callback) {
  const observer = new MutationObserver((mutations, obs) => {
    if (document.querySelector(selector)) {
      obs.disconnect(); // Ngừng quan sát khi tìm thấy phần tử
      callback();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

waitForElement("table", () => {
  const targetNode = document.querySelector("table");
  if (targetNode) {
    const observer = new MutationObserver(() => {
      extractTransactions();
    });
    observer.observe(targetNode, { childList: true, subtree: true });
  }

  function extractTransactions() {
    let transactions = []; // ✅ Định nghĩa đúng phạm vi

    document.querySelectorAll("table tr").forEach((row) => {
      let columns = row.querySelectorAll("td");
      if (columns.length > 0) {
        transactions.push({
          date: columns[1] ? columns[1].innerText : "", // Kiểm tra null/undefined
          amount: columns[2] ? columns[2].innerText : "",
          description: columns[4] ? columns[4].innerText : "",
        });
      }
    });
    console.log("Danh sách giao dịch:", transactions);
    chrome.storage.local.set({ transactions }, () => {
      console.log("Dữ liệu đã được lưu vào local storage");
      chrome.runtime.sendMessage({
        action: "sendTransactionData",
        data: transactions
      });
    });
    chrome.storage.local.get(null, (data) => console.log(data));
  }
  extractTransactions(); // Gọi lần đầu để lấy dữ liệu nếu bảng đã có
});

